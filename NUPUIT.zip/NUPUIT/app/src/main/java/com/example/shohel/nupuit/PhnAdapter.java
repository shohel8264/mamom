package com.example.shohel.nupuit;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Shohel on 3/31/2017.
 */

public class PhnAdapter extends RecyclerView.Adapter<PhnAdapter.MyViewHolder> {
    private Context mContext;
    private List<Phone> phnlist;

    public PhnAdapter(Context mContext,List<Phone> phnlist) {
        this.phnlist = phnlist;
        this.mContext = mContext;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View Agrview = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.name_number, parent, false);

        return new MyViewHolder(Agrview);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Phone phne=phnlist.get(position);
        holder.name.setText(phnlist.get(position).getName());
        holder.phn.setText(phnlist.get(position).getPhone());
    }

    @Override
    public int getItemCount() {
        return phnlist.size() ;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, phn;
        public MyViewHolder(View itemView) {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.textViewName);
            phn=(TextView)itemView.findViewById(R.id.textViewPhn);
        }
    }
}
